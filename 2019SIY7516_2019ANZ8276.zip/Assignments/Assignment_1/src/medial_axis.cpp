#include "medial_axis.h"

void MedialAxis_C::ApplyHoughTransform()
{


}

void MedialAxis_C::ApplyGradient()
{
}

void MedialAxis_C::GetHoughLine()
{



}

void MedialAxis_C::GetEdge()
{

}

void MedialAxis_C::GetForegroundImage()
{


}

void MedialAxis_C::ApplyMorphologicalOperator()
{
}

void MedialAxis_C::GetMedialAxis()
{



}
