**Relevent Docs**
- [x] Video stream & Background Subtraction  : https://docs.opencv.org/3.1.0/d1/dc5/tutorial_background_subtraction.html
- [x] Morphological Transformations : https://docs.opencv.org/3.4/d3/dbe/tutorial_opening_closing_hats.html
- [x] Image Derivative : https://docs.opencv.org/3.4/d2/d2c/tutorial_sobel_derivatives.html
- [x] Hough Transform : https://docs.opencv.org/3.4/d9/db0/tutorial_hough_lines.html
- [x] Drawing shapes on Image : https://docs.opencv.org/3.1.0/d3/d96/tutorial_basic_geometric_drawing.html