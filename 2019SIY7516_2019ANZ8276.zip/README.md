Repository for COL780

- [x] Re-organize code
- [ ] Add install project feature, so that binaries can be exported and given for assignment submission.

**External libs**

- Eigen3
- nlohmann/json

**SETUP**

- Please copy the videos/video into data/videos
- Please paste the name of the video you want to work on, in turing_params.json
- Good to go!